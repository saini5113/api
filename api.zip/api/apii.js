const http = require('http');
const fs = require('fs');


const apidata = fs.readFileSync('aapi.json', 'utf-8');
const api_temp_infoo = fs.readFileSync('api_temp_infoo.html', 'utf-8');
const api_temp_holderr = fs.readFileSync('api_temp_holderr.html', 'utf-8');
const apiobject = JSON.parse(apidata);

 
const replacePlaceHolders = (api_temp_infoo, item_object) => {

    let result_html = api_temp_infoo.replace('{@id@}', item_object.id);
    result_html = result_html.replace('{@name@}', item_object.name);
    result_html = result_html.replace('{@job@}', item_object.job);
    result_html = result_html.replace('{@phone_number@}', item_object.phone_number);

    return result_html

   
}





const server = http.createServer((req, res) => {

    const patname = req.url;

    if (patname === '/') {

        res.setHeader('content-type', 'text/html');
        const apihtml = apiobject.map(item_object => replacePlaceHolders(api_temp_infoo, item_object));
       
        const a = api_temp_holderr.replace('{@user-information@}',apihtml);
        res.end(a);
        
        // console.log(apihtml);
        
        
        res.end();
    }

})

server.listen(7000, 'localhost', () => console.log("started at 7000"));